#!/usr/bin/env python3

import numpy, rclpy

from asl_tb3_lib.control import BaseController
from asl_tb3_lib.math_utils import wrap_angle
from asl_tb3_msgs.msg import TurtleBotControl, TurtleBotState

from std_msgs.msg import Int64, Bool

class PerceptionController(BaseController):
    def __init__(self, node_name: str = "perception_controller") -> None:
        super().__init__(node_name)
        self.declare_parameter("active", True)
        # self.flag = 0           # 0 = we can update, 1 = we can't update
        self.last_time_change = self.get_clock().now().nanoseconds / 1e9 - 5
        
    @property
    def active(self) -> bool:
        self.get_parameter("active").value
        pass
    
    def compute_control(self) -> TurtleBotControl:
        command = TurtleBotControl()
        command.omega = 0.5

        current_time = self.get_clock().now().nanoseconds / 1e9
            
        if (self.active == False):
            command.omega = 0.0
            if (current_time >= (self.last_time_change + 5)):
                # do nothing
                pass
            self.set_parameters([rclpy.Parameter("active", value=True)])
            command.omega = 0.5
            
            # if self.flag == 0:
            #     command.omega = 0.0
            #     self.flag = 1
            #     self.last_time_change = self.get_clock().now().nanoseconds / 1e9 
            #     print("CHANGING to 5 Sec delay")
            #     print("last change: " + str(self.last_time_change))
            
            # else:
            #     current_time = self.get_clock().now().nanoseconds / 1e9
            #     print("last change: " + str(self.last_time_change))
            #     print("current time: " + str(current_time))
                
            #     if (current_time <= (self.last_time_change + 5)):
            #         print("waiting")
            #         pass            # do nothing
                
            #     else:
            #         print("done waiting")
            #         print("last change: " + str(self.last_time_change))
            #         print("current time: " + str(current_time))
            #         self.set_parameters([rclpy.Parameter("active", value=True)])
            #         self.flag = 0
            #         command.omega = 0.5
         
        return command
    
if __name__ == "__main__":
    rclpy.init()        # initialize ROS2 context (must run before any other rclpy call)
    node = PerceptionController() 
    rclpy.spin(node)    # Use ROS2 built-in schedular for executing the node
    rclpy.shutdown()    # cleanly shutdown ROS2 context